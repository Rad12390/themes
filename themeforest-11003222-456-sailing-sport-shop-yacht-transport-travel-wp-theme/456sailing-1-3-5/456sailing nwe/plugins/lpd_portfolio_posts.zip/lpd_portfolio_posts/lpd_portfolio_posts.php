<?php
/**
* Plugin Name: Portfolio Posts
* Plugin URI: http://support.lpd-themes.com/
* Description: Portfolio Post Type.
* Version: 1.0
* Author: lidplussdesign
* Author URI: http://support.lpd-themes.com/
* License: GPL (General Public License)
*/

$dir = dirname(__FILE__);

include_once ($dir. '/post-type/portfolio.php');